<?php
/**
 * @fileName: PwCollect.php
 * @author: dongyong<dongyong.ydy@alibaba-inc.com>
 * @license: http://www.phpwind.com
 * @version: $Id
 * @lastchange: 2015-01-09 14:57:30
 * @desc: 
 **/

class PwCollect {

}
