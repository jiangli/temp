<?php
/**
 * @fileName: PwBanner.php
 * @author: dongyong<dongyong.ydy@alibaba-inc.com>
 * @license: http://www.phpwind.com
 * @version: $Id
 * @lastchange: 2014-12-29 16:11:15
 * @desc: 
 **/

class PwBanner {

    const BANNER_TYPE_NATIVE_INDEX = 'native_index';
}
